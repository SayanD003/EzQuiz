<?php
$conn = mysqli_connect("sql103.infinityfree.com", "if0_37177274", "W2nQsX69O0uF9f", "if0_37177274_ezquiz");
mysqli_select_db($conn,"if0_37177274_ezquiz");
?>