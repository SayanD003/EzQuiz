<footer class="sticky-footer bg-white mt-4">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; EzQuiz 2024</span>
                    </div>
                </div>
            </footer>