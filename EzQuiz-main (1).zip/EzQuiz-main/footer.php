<div class="container">  
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 border-top">
      <p class="col-md-4 mb-0 text-muted">© 2024 EzQuiz, All rights reserved</p>
  
      <ul class="footer-menu nav col-md-4 justify-content-end">
        <li class="nav-item"><a href="contact.php" class="nav-link px-2 text-muted">Contact Us</a></li>
      </ul>
    </footer>
    </div>