# EzQuiz
An online quiz website made with HTML, CSS, Javascript and PHP
